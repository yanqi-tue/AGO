"""Full-diet (25 dietary features) >=4500 g LR complexity sensitivity.

For four model definitions, replaces diet_short with diet=indices 66..90 and
explain_diet_short with explain_diet from the original source script. In each
outer training fold, fits the full weighted elastic-net LR, estimates a local
active-set effective degrees of freedom, selects the top 5/10/15/20 percent
of coefficients by absolute value, refits, then scores the held-out fold.

Original diet_short results are read only for fold-ID verification. All outputs
go to a new directory; the original analysis, figures and tables are untouched.
"""

from __future__ import annotations

import argparse
import ast
import json
import math
from pathlib import Path

import numpy as np

import task1_compute_lr as base


DEFAULT_OLD_RESULTS = Path(
    r"C:\Users\ikaros\Desktop\postdoc\AOGS\AOGS"
    r"\sex_removed_lr_task1_bundle\sex_removed_lr_task1\results_task1_final"
)
DEFAULT_OUTPUT = Path(
    r"C:\Users\ikaros\Desktop\postdoc\AOGS\AOGS\bw4500_full_diet_complexity"
)
DIET = list(range(66, 91))  # Original: list(range(66,79))+list(range(79,91))
FRACTIONS = (0.05, 0.10, 0.15, 0.20)
MODEL_INDICES = {
    "model1": base.DEMOGRAPHIC + DIET + base.V1,
    "model2": base.DEMOGRAPHIC + DIET + base.V1 + base.V2 + base.U2,
    "model3": base.DEMOGRAPHIC + DIET + base.V1 + base.V3 + base.U3,
    "combined": base.DEMOGRAPHIC + DIET + base.V1 + base.V2 + base.U2 + base.V3 + base.U3,
}
DISPLAY_COMPONENTS = {
    "model1": ("explain_demographic", "explain_diet", "clinical_measurment_V1"),
    "model2": ("explain_demographic", "explain_diet", "clinical_measurment_V1",
               "clinical_measurment_V2", "explain_u2"),
    "model3": ("explain_demographic", "explain_diet", "clinical_measurment_V1",
               "clinical_measurment_V3", "explain_u3"),
    "combined": ("explain_demographic", "explain_diet", "clinical_measurment_V1",
                 "clinical_measurment_V2", "explain_u2", "clinical_measurment_V3", "explain_u3"),
}


def original_display_lists(path: Path) -> dict[str, list[str]]:
    """Read only constant display-list assignments, without running source code."""
    tree = ast.parse(path.read_text(encoding="utf-8"))
    needed = set().union(*DISPLAY_COMPONENTS.values())
    values = {}
    for node in tree.body:
        if (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id in needed):
            values[node.targets[0].id] = ast.literal_eval(node.value)
    if set(values) != needed or len(values["explain_diet"]) != len(DIET):
        raise ValueError("Original explain_diet/display lists are missing or misaligned")
    return values


def auc(y: np.ndarray, score: np.ndarray) -> float:
    y = np.asarray(y, dtype=np.int8)
    score = np.asarray(score, dtype=np.float64)
    positives = int(y.sum())
    negatives = len(y) - positives
    if positives == 0 or negatives == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    _, starts, counts = np.unique(score[order], return_index=True, return_counts=True)
    rank_ordered = np.repeat(starts + (counts + 1) / 2.0, counts)
    ranks = np.empty(len(y), dtype=float)
    ranks[order] = rank_ordered
    return float((ranks[y == 1].sum() - positives * (positives + 1) / 2.0)
                 / (positives * negatives))


def local_predictor_edf(x: np.ndarray, y: np.ndarray, coef: np.ndarray) -> tuple[float, int]:
    """Local active-set trace EDF for fixed C=.1, L1 ratio=.3 and class weight=10."""
    active = np.flatnonzero(coef[1:] != 0.0)
    a = np.column_stack((np.ones(len(y)), x[:, active]))
    probability = base.sigmoid(coef[0] + x @ coef[1:])
    w = np.where(y == 1, 10.0, 1.0) * probability * (1.0 - probability) / len(y)
    h = a.T @ (a * w[:, None])
    p = np.diag(np.r_[0.0, np.repeat((1.0 - 0.3) / (0.1 * len(y)), len(active))])
    df = float(np.trace(np.linalg.solve(h + p, h))) - 1.0
    return df, len(active)


def summarize_auc(y: np.ndarray, original: np.ndarray, small: np.ndarray,
                  boot: np.ndarray) -> dict:
    original_auc = auc(y, original)
    small_auc = auc(y, small)
    delta = np.empty(len(boot), dtype=np.float64)
    for i, index in enumerate(boot):
        delta[i] = auc(y[index], small[index]) - auc(y[index], original[index])
    low, high = np.nanpercentile(delta, [2.5, 97.5])
    return {
        "full_auc": original_auc,
        "reduced_auc": small_auc,
        "reduced_minus_full_auc": small_auc - original_auc,
        "paired_delta_ci_low": float(low),
        "paired_delta_ci_high": float(high),
    }


def execute(args: argparse.Namespace) -> None:
    if args.repeat_start < 0 or args.repeat_count < 1 or args.bootstrap < 1:
        raise ValueError("repeat-start, repeat-count, and bootstrap are invalid")
    display_parts = original_display_lists(args.original_code)
    source_x = np.load(args.source_dir / "macrodata_num_513.npy", allow_pickle=False)
    source_names = np.load(args.source_dir / "macrodata_num_name_513.npy", allow_pickle=False).astype(str)
    y = np.load(args.source_dir / "LGA_label4500_513.npy", allow_pickle=False).astype(np.int8)
    reference_y = np.load(args.old_results / "labels" / "bw4500.npy", allow_pickle=False)
    if source_x.shape[0] != len(y) or not np.array_equal(y, reference_y) or y.sum() != 77:
        raise ValueError("Source row alignment or >=4500 g event count differs from Task 1")
    if len(set(DIET)) != len(DIET) or source_names[88] != "AHEI_SODIUM":
        raise ValueError("Full diet indices do not match the source matrix")
    for model, indices in MODEL_INDICES.items():
        if len(set(indices)) != len(indices) or 48 in indices:
            raise ValueError(f"Duplicate feature or fetal sex in {model}")
    original_fold_id = np.load(
        args.old_results / "combinations" / "bw4500__model1" / "fold_id.npy", mmap_mode="r"
    )
    end = args.repeat_start + args.repeat_count
    if end > len(original_fold_id) or original_fold_id.shape[1] != len(y):
        raise ValueError("Requested repeats unavailable in Task 1")
    for repeat in range(args.repeat_start, end):
        expected = base.stratified_folds(y, 10, repeat)
        if not np.array_equal(expected, original_fold_id[repeat]):
            raise ValueError(f"The original fold IDs differ at repeat {repeat}")

    boot = np.random.default_rng(args.seed).integers(
        0, len(y), size=(args.bootstrap, len(y)), dtype=np.int32
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "outcome": "bw4500 label from source NPY: >=4500 g",
        "n": len(y), "events": int(y.sum()),
        "repeats": args.repeat_count, "repeat_start": args.repeat_start,
        "folds_per_repeat": 10, "bootstrap": args.bootstrap,
        "model_specification": "LR, elastic-net C=0.1, l1_ratio=0.3, class weight 1:10",
        "diet": "all 25 source columns 66..90, original explain_diet display list",
        "feature_selection": "top absolute coefficients inside each outer training fold; ceil(fraction * candidate count)",
        "edf": "local fixed-penalty active-set trace, predictor EDF excludes intercept; approximation does not include all selection uncertainty",
        "models": {},
    }

    for model in args.models:
        indices = np.asarray(MODEL_INDICES[model], dtype=np.int16)
        xx = np.ascontiguousarray(source_x[:, indices], dtype=np.float64)
        display_names = sum((display_parts[part] for part in DISPLAY_COMPONENTS[model]), [])
        if len(display_names) != len(indices):
            raise ValueError(f"Original display_name list does not match {model} feature count")
        model_dir = args.output_dir / model
        model_dir.mkdir(parents=True, exist_ok=True)
        np.save(model_dir / "candidate_source_indices.npy", indices)
        np.save(model_dir / "candidate_source_names.npy", source_names[indices])
        np.save(model_dir / "display_name_original_expression.npy", np.asarray(display_names, dtype=str))
        # The original V1 and some U3 display lists are not aligned to source
        # columns. Source names/indices are authoritative for selected features.

        p_count = len(indices)
        coefficient = np.full((args.repeat_count, 10, p_count + 1), np.nan, dtype=np.float32)
        edf = np.full((args.repeat_count, 10), np.nan, dtype=np.float64)
        nonzero = np.zeros((args.repeat_count, 10), dtype=np.int16)
        full_oof = np.full((args.repeat_count, len(y)), np.nan, dtype=np.float32)
        reduced_oof = {q: np.full_like(full_oof, np.nan) for q in FRACTIONS}
        reduced_edf = {
            q: np.full((args.repeat_count, 10), np.nan, dtype=np.float64)
            for q in FRACTIONS
        }
        reduced_nonzero = {
            q: np.zeros((args.repeat_count, 10), dtype=np.int16)
            for q in FRACTIONS
        }
        selected_indices = {
            q: np.full((args.repeat_count, 10, math.ceil(p_count * q)), -1, dtype=np.int16)
            for q in FRACTIONS
        }
        fit_initial = None
        for rr, repeat in enumerate(range(args.repeat_start, end)):
            fold_ids = np.asarray(original_fold_id[repeat])
            for fold in range(10):
                test = fold_ids == fold
                train = ~test
                fit_initial, iterations, converged = base.fit_weighted_elasticnet_lr(
                    xx[train], y[train], 10, c=0.1, l1_ratio=0.3,
                    max_iter=args.max_iter, tol=2e-5, initial=fit_initial,
                )
                if not converged:
                    raise RuntimeError(
                        f"Full model did not converge: {model}, repeat {repeat}, fold {fold}, "
                        f"iterations {iterations}"
                    )
                coefficient[rr, fold] = fit_initial
                edf[rr, fold], nonzero[rr, fold] = local_predictor_edf(
                    xx[train], y[train], fit_initial
                )
                full_oof[rr, test] = base.sigmoid(
                    xx[test] @ fit_initial[1:] + fit_initial[0]
                )
                ranking = np.argsort(-np.abs(fit_initial[1:]), kind="mergesort")
                for q in FRACTIONS:
                    chosen = np.sort(ranking[:selected_indices[q].shape[2]])
                    selected_indices[q][rr, fold] = indices[chosen]
                    reduced_initial = np.r_[fit_initial[0], fit_initial[1:][chosen]]
                    small_coef, small_iterations, small_converged = base.fit_weighted_elasticnet_lr(
                        xx[train][:, chosen], y[train], 10, c=0.1, l1_ratio=0.3,
                        max_iter=args.max_iter, tol=2e-5, initial=reduced_initial,
                    )
                    if not small_converged:
                        raise RuntimeError(
                            f"Reduced model did not converge: {model}, repeat {repeat}, "
                            f"fold {fold}, top {q}, iterations {small_iterations}"
                        )
                    reduced_edf[q][rr, fold], reduced_nonzero[q][rr, fold] = (
                        local_predictor_edf(xx[train][:, chosen], y[train], small_coef)
                    )
                    reduced_oof[q][rr, test] = base.sigmoid(
                        xx[test][:, chosen] @ small_coef[1:] + small_coef[0]
                    )
            if (rr + 1) % 10 == 0 or rr == 0:
                print(f"{model}: {rr + 1}/{args.repeat_count} repeats", flush=True)

        if not np.isfinite(full_oof).all() or any(
            not np.isfinite(pred).all() for pred in reduced_oof.values()
        ):
            raise ValueError(f"An OOF prediction is missing for {model}")
        np.save(model_dir / "fold_id.npy", original_fold_id[args.repeat_start:end])
        np.save(model_dir / "full_coefficients_by_repeat_fold.npy", coefficient)
        np.save(model_dir / "full_local_predictor_edf_by_repeat_fold.npy", edf)
        np.save(model_dir / "full_nonzero_by_repeat_fold.npy", nonzero)
        np.save(model_dir / "full_oof_by_repeat.npy", full_oof)
        full_mean = full_oof.astype(np.float64).mean(axis=0)
        np.save(model_dir / "full_oof_mean.npy", full_mean)
        model_report = {
            "candidate_parameters_excluding_intercept": p_count,
            "mean_nonzero_full": float(nonzero.mean()),
            "mean_local_predictor_edf_full": float(edf.mean()),
            "local_edf_percentile_2_5": float(np.percentile(edf, 2.5)),
            "local_edf_percentile_97_5": float(np.percentile(edf, 97.5)),
            "full_auc": auc(y, full_mean),
            "subsets": {},
        }
        for q in FRACTIONS:
            key = f"top_{round(q * 100)}pct"
            subset_dir = model_dir / key
            subset_dir.mkdir(parents=True, exist_ok=True)
            pred_mean = reduced_oof[q].astype(np.float64).mean(axis=0)
            np.save(subset_dir / "oof_by_repeat.npy", reduced_oof[q])
            np.save(subset_dir / "oof_mean.npy", pred_mean)
            np.save(subset_dir / "selected_source_indices_by_repeat_fold.npy", selected_indices[q])
            np.save(subset_dir / "local_predictor_edf_by_repeat_fold.npy", reduced_edf[q])
            np.save(subset_dir / "nonzero_by_repeat_fold.npy", reduced_nonzero[q])
            unique, counts = np.unique(selected_indices[q], return_counts=True)
            order = np.argsort(-counts, kind="mergesort")
            model_report["subsets"][key] = {
                "features_per_fit": selected_indices[q].shape[2],
                "mean_nonzero": float(reduced_nonzero[q].mean()),
                "mean_local_predictor_edf": float(reduced_edf[q].mean()),
                "local_edf_percentile_2_5": float(np.percentile(reduced_edf[q], 2.5)),
                "local_edf_percentile_97_5": float(np.percentile(reduced_edf[q], 97.5)),
                "selection_frequency": [
                    {"source_index": int(unique[j]), "source_name": str(source_names[unique[j]]),
                     "fraction_of_fits_selected": float(counts[j] / (args.repeat_count * 10))}
                    for j in order
                ],
                **summarize_auc(y, full_mean, pred_mean, boot),
            }
        report["models"][model] = model_report
        (args.output_dir / "summary.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    print(f"Complete: {args.output_dir / 'summary.json'}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=base.SOURCE_DIR)
    parser.add_argument("--old-results", type=Path, default=DEFAULT_OLD_RESULTS)
    parser.add_argument("--original-code", type=Path, default=base.SOURCE_CODE)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--models", nargs="+", choices=base.MODEL_ORDER, default=base.MODEL_ORDER)
    parser.add_argument("--repeat-start", type=int, default=0)
    parser.add_argument("--repeat-count", type=int, default=1,
                        help="Use 100 for all original repeated splits")
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260925)
    parser.add_argument("--max-iter", type=int, default=120)
    execute(parser.parse_args())


if __name__ == "__main__":
    main()
