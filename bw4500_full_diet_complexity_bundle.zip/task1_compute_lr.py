"""Stage 1: reproduce the 4-outcome x 4-model logistic-regression analysis.

This file deliberately uses the feature indices in numom2b_macro_LR_513_925.py.
It saves participant-level out-of-fold (OOF) scores and the data required for
ROC, PR, coefficient, threshold, and later calibration/decision-curve figures.
Calibration itself and the nonlinear S9 comparison are deferred.

The only runtime dependencies are NumPy and pandas.  The elastic-net logistic
optimizer below minimizes weighted log loss with L1/L2 penalties, matching the
source model specification (C=.1, l1_ratio=.3), without requiring scikit-learn.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd


SOURCE_DIR = Path(r"C:\Users\ikaros\Desktop\phd\macrosomia")
SOURCE_CODE = Path(r"C:\python_code\numom2b_macro_LR_513_925.py")
DEFAULT_OUTPUT = Path(r"C:\Users\ikaros\Desktop\postdoc\AOGS\AOGS\sex_removed_lr_outputs")

DEMOGRAPHIC = [39, 41, 42, 43, 44, 46, 47, 50, 64]
DIET_SHORT = [88, 89]  # Exactly as in the source: AHEI sodium and alcohol.
V1 = [40, 51, 54, 55, 56, 57, 58, 59]
V2 = [52, 60, 61, 65]
U2 = [32, 34, 35, 36, 37, 38]
V3 = [53, 62, 63]
U3 = [0, 2, 3, 4, 5, 6, 8, 9, 10, 11]
MODEL_INDICES = {
    "model1": DEMOGRAPHIC + DIET_SHORT + V1,
    "model2": DEMOGRAPHIC + DIET_SHORT + V1 + V2 + U2,
    "model3": DEMOGRAPHIC + DIET_SHORT + V1 + V3 + U3,
    "combined": DEMOGRAPHIC + DIET_SHORT + V1 + V2 + U2 + V3 + U3,
}
OUTCOME_WEIGHT = {"bw4000": 5, "bw4500": 10, "lga90": 5, "lga97": 5}
OUTCOME_ORDER = ["bw4000", "bw4500", "lga90", "lga97"]
MODEL_ORDER = ["model1", "model2", "model3", "combined"]

DISPLAY = {
    0: "GA at visit 3", 2: "BPD at visit 3", 3: "HC at visit 3",
    4: "AC at visit 3", 5: "FL at visit 3",
    # U3AB06a/U3AB06c/U3AB06d/U3AB07/U3AB08 keep source codes until
    # their conflicting source-script and feature-map display names are verified.
    32: "GA at visit 2", 34: "BPD at visit 2", 35: "HC at visit 2",
    36: "AC at visit 2", 37: "FL at visit 2", 38: "EFW at visit 2",
    39: "Age", 40: "BMI at visit 1", 41: "Non-Hispanic White",
    42: "Non-Hispanic Black", 43: "Hispanic", 44: "Asian and other race/ethnicity",
    46: "Income", 47: "Smoking before pregnancy", 50: "Pre-pregnancy BMI",
    51: "GWG at visit 1", 52: "GWG at visit 2", 53: "GWG at visit 3",
    54: "Waist circumference at visit 1", 55: "Waist over iliac crest at visit 1",
    56: "Hip circumference at visit 1", 57: "Neck circumference at visit 1",
    58: "SBP at visit 1", 59: "DBP at visit 1", 60: "SBP at visit 2",
    61: "DBP at visit 2", 62: "SBP at visit 3", 63: "DBP at visit 3",
    64: "Preexisting diabetes", 65: "Gestational diabetes",
    88: "AHEI - Sodium intake score", 89: "AHEI - Alcoholic drinks score",
}


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def save(path: Path, array: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    np.save(path, np.asarray(array), allow_pickle=False)


def load_inputs(source_dir: Path):
    paths = {
        "features": source_dir / "macrodata_num_513.npy",
        "names": source_dir / "macrodata_num_name_513.npy",
        "bw4000": source_dir / "LGA_label4000_513.npy",
        "bw4500": source_dir / "LGA_label4500_513.npy",
        "birthweight": source_dir / "BW_21.npy",
        "gestational_age": source_dir / "GA_21.npy",
        "centiles": source_dir / "intergrowth_birthweight_for_ga_results.csv",
    }
    for path in paths.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    x = np.load(paths["features"], allow_pickle=False).astype(np.float64)
    names = np.load(paths["names"], allow_pickle=False).astype(str)
    bw4000 = np.load(paths["bw4000"], allow_pickle=False).astype(np.int8)
    bw4500 = np.load(paths["bw4500"], allow_pickle=False).astype(np.int8)
    birthweight = np.load(paths["birthweight"], allow_pickle=False)
    gestational_age = np.load(paths["gestational_age"], allow_pickle=False)
    centile_df = pd.read_csv(paths["centiles"])
    centile = centile_df["bw_for_ga_centile"].to_numpy(dtype=float)
    participant_id = centile_df["id"].to_numpy(dtype=np.int64)
    labels = {
        "bw4000": bw4000,
        "bw4500": bw4500,
        "lga90": (centile > 90).astype(np.int8),
        "lga97": (centile > 97).astype(np.int8),
    }
    n = x.shape[0]
    if x.shape[1] != len(names) or any(len(a) != n for a in
        [*labels.values(), birthweight, gestational_age, centile, participant_id]):
        raise ValueError("Source arrays have inconsistent row counts or feature names.")
    if not np.isfinite(x).all() or not np.isfinite(centile).all():
        raise ValueError("Selected source data contain NaN or infinite values.")
    if len(np.unique(participant_id)) != n:
        raise ValueError("Participant IDs are duplicated.")
    if not np.allclose(birthweight, centile_df["birthweight_g"].to_numpy()):
        raise ValueError("CSV and BW_21.npy have different row order.")
    if not np.allclose(gestational_age, centile_df["ga_weeks"].to_numpy()):
        raise ValueError("CSV and GA_21.npy have different row order.")
    if np.any(labels["bw4500"] > labels["bw4000"]):
        raise ValueError("BW4500 cases are not a subset of BW4000 cases.")
    if np.any(labels["lga97"] > labels["lga90"]):
        raise ValueError("LGA97 cases are not a subset of LGA90 cases.")
    for outcome, y in labels.items():
        if set(np.unique(y)) != {0, 1}:
            raise ValueError(f"{outcome} is not binary with both classes present.")
        if np.count_nonzero(y) >= n / 2:
            raise ValueError(f"Positive class is not the minority for {outcome}.")
    for model, indices in MODEL_INDICES.items():
        if len(indices) != len(set(indices)):
            raise ValueError(f"Duplicate feature in {model}.")
        if 48 in indices or "gender_babies" in names[indices]:
            raise ValueError(f"Fetal sex leaked into {model}.")
        if not np.isfinite(x[:, indices]).all():
            raise ValueError(f"Nonfinite feature in {model}.")
    if names[88] != "AHEI_SODIUM" or names[89] != "AHEI_ALCDRKS":
        raise ValueError("diet_short indices no longer match the source data.")
    checks = {
        "n_participants": n,
        "outcome_counts": {k: {"positive": int(v.sum()), "negative": int(n-v.sum())}
                           for k, v in labels.items()},
        "csv_birthweight_matches_npy": True,
        "csv_gestational_age_matches_npy": True,
        "bw4000_npy_matches_ge_4000": bool(np.array_equal(bw4000, birthweight >= 4000)),
        "bw4500_npy_matches_ge_4500": bool(np.array_equal(bw4500, birthweight >= 4500)),
        "birthweight_exactly_4000": int(np.count_nonzero(birthweight == 4000)),
        "birthweight_exactly_4500": int(np.count_nonzero(birthweight == 4500)),
        "sex_index_48_excluded_all_models": True,
        "diet_short_source_indices": DIET_SHORT,
        "feature_count_by_model": {k: len(v) for k, v in MODEL_INDICES.items()},
    }
    return x, names, labels, participant_id, checks, paths


def stratified_folds(y: np.ndarray, n_splits: int, seed: int) -> np.ndarray:
    """Match StratifiedKFold(shuffle=True, random_state=seed) fold IDs."""
    rng = np.random.RandomState(seed)
    classes, first_index, inverse = np.unique(
        y, return_index=True, return_inverse=True)
    ordered_classes = np.argsort(first_index)
    encoding = np.empty(len(classes), dtype=np.int8)
    encoding[ordered_classes] = np.arange(len(classes), dtype=np.int8)
    encoded = encoding[inverse]
    sorted_encoded = np.sort(encoded)
    allocation = np.asarray([
        np.bincount(sorted_encoded[i::n_splits], minlength=len(classes))
        for i in range(n_splits)])
    folds = np.full(len(y), -1, dtype=np.int8)
    for cls in range(len(classes)):
        folds_for_class = np.arange(n_splits).repeat(allocation[:, cls])
        rng.shuffle(folds_for_class)
        folds[encoded == cls] = folds_for_class
    if np.any(folds < 0):
        raise AssertionError("An observation was not assigned to a fold.")
    return folds


def sigmoid(z: np.ndarray) -> np.ndarray:
    out = np.empty_like(z, dtype=np.float64)
    pos = z >= 0
    out[pos] = 1 / (1 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])
    out[~pos] = ez / (1 + ez)
    return out


def fit_weighted_elasticnet_lr(
    x: np.ndarray, y: np.ndarray, positive_weight: int, *, c: float = 0.1,
    l1_ratio: float = 0.3, max_iter: int = 80, tol: float = 2e-5,
    initial: np.ndarray | None = None,
) -> tuple[np.ndarray, int, bool]:
    """Deterministic proximal-Newton fit of weighted, elastic-net binary LR.

    Objective: mean(weighted log loss) + [1/(C*n)] *
    {l1_ratio*||beta||_1 + (1-l1_ratio)*||beta||_2^2/2}; intercept unpenalized.
    Returned vector is [intercept, coefficient_1, ...].
    """
    n, p = x.shape
    y_float = y.astype(np.float64)
    weight = np.where(y == 1, float(positive_weight), 1.0)
    alpha = 1.0 / (c * n)
    l1 = alpha * l1_ratio
    l2 = alpha * (1.0 - l1_ratio)
    if initial is None:
        pos_fraction = np.sum(weight * y_float) / np.sum(weight)
        b = np.zeros(p + 1, dtype=np.float64)
        b[0] = math.log(pos_fraction / (1 - pos_fraction))
    else:
        b = np.asarray(initial, dtype=np.float64).copy()
        if b.shape != (p + 1,):
            raise ValueError("Initial coefficient vector has wrong length.")
    a = np.column_stack((np.ones(n), x))

    def objective(theta: np.ndarray) -> float:
        linear = a @ theta
        loss = np.dot(weight, np.logaddexp(0, linear) - y_float * linear) / n
        return float(loss + l1 * np.abs(theta[1:]).sum() +
                     0.5 * l2 * np.dot(theta[1:], theta[1:]))

    converged = False
    for iteration in range(1, max_iter + 1):
        prob = sigmoid(a @ b)
        g = a.T @ (weight * (prob-y_float)) / n
        g[1:] += l2 * b[1:]
        kkt = max(abs(g[0]), np.max(np.where(
            b[1:] != 0, np.abs(g[1:] + l1 * np.sign(b[1:])),
            np.maximum(np.abs(g[1:]) - l1, 0))))
        if kkt < tol:
            converged = True
            break
        curvature = weight * prob * (1-prob) / n
        h = a.T @ (a * curvature[:, None])
        diagonal = np.arange(1, len(b))
        h[diagonal, diagonal] += l2
        rhs = h @ b - g
        proposal = b.copy()
        h_proposal = h @ proposal
        for _ in range(250):
            largest_change = 0.0
            for j in range(len(b)):
                rho = rhs[j] - h_proposal[j] + h[j, j] * proposal[j]
                if j == 0:
                    new_value = rho / h[j, j]
                else:
                    new_value = np.sign(rho) * max(abs(rho)-l1, 0) / h[j, j]
                change = new_value - proposal[j]
                if change:
                    proposal[j] = new_value
                    h_proposal += h[:, j] * change
                    largest_change = max(largest_change, abs(change))
            if largest_change < tol / 10:
                break
        old_obj = objective(b)
        step = 1.0
        while step > 1 / 4096:
            candidate = b + step * (proposal-b)
            if objective(candidate) <= old_obj + 1e-12:
                break
            step /= 2
        b = candidate
    return b, iteration, converged


def roc_curve(y: np.ndarray, p: np.ndarray):
    order = np.argsort(-p, kind="mergesort")
    ys, ps = y[order], p[order]
    last = np.r_[np.flatnonzero(np.diff(ps)), len(ps)-1]
    tp = np.cumsum(ys)[last]
    fp = 1 + last - tp
    tpr = np.r_[0.0, tp / np.sum(y)]
    fpr = np.r_[0.0, fp / (len(y)-np.sum(y))]
    thresholds = np.r_[np.inf, ps[last]]
    return fpr, tpr, thresholds


def precision_recall(y: np.ndarray, p: np.ndarray):
    order = np.argsort(-p, kind="mergesort")
    ys, ps = y[order], p[order]
    last = np.r_[np.flatnonzero(np.diff(ps)), len(ps)-1]
    tp = np.cumsum(ys)[last]
    precision = tp / (last + 1)
    recall = tp / np.sum(y)
    return np.r_[1.0, precision], np.r_[0.0, recall], ps[last]


def performance(y: np.ndarray, p: np.ndarray) -> np.ndarray:
    fpr, tpr, _ = roc_curve(y, p)
    precision, recall, _ = precision_recall(y, p)
    ap = float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))
    return np.array([
        np.trapezoid(tpr, fpr), ap, np.trapezoid(precision, recall),
        np.mean((p-y)**2),
    ], dtype=float)


def top_risk_metrics(y: np.ndarray, p: np.ndarray, fraction: float) -> tuple:
    n = len(y)
    k = math.ceil(n * fraction)
    ranked = np.argsort(-p, kind="mergesort")
    selected = ranked[:k]
    predicted = np.zeros(n, dtype=bool)
    predicted[selected] = True
    tp = int(np.sum(predicted & (y == 1)))
    fp = int(np.sum(predicted & (y == 0)))
    fn = int(np.sum(~predicted & (y == 1)))
    tn = int(np.sum(~predicted & (y == 0)))
    return (fraction, k, float(p[selected[-1]]), tp, fp, fn, tn,
            tp/(tp+fn), tn/(tn+fp), tp/(tp+fp), tn/(tn+fn))


def bootstrap_metrics(y: np.ndarray, p: np.ndarray, indices: np.ndarray) -> np.ndarray:
    result = np.full((len(indices), 4), np.nan, dtype=np.float64)
    for b, ix in enumerate(indices):
        yy, pp = y[ix], p[ix]
        if yy.min() != yy.max():
            result[b] = performance(yy, pp)
    return result


def execute(args: argparse.Namespace) -> None:
    start = time.time()
    x, names, labels, participant_id, checks, paths = load_inputs(args.source_dir)
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    save(output / "participant_id.npy", participant_id)
    for outcome, y in labels.items():
        save(output / "labels" / f"{outcome}.npy", y)
    for model, indices in MODEL_INDICES.items():
        save(output / "features" / f"{model}_indices.npy", np.array(indices, dtype=np.int16))
        save(output / "features" / f"{model}_source_names.npy", names[indices])
        save(output / "features" / f"{model}_display_names.npy",
             np.array([DISPLAY.get(i, names[i]) for i in indices], dtype=str))
    source_hashes = {k: file_sha256(v) for k, v in paths.items()}
    if SOURCE_CODE.is_file():
        source_hashes["original_code"] = file_sha256(SOURCE_CODE)
    manifest = {
        "status": "running", "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source_dir": str(args.source_dir), "source_sha256": source_hashes,
        "checks": checks, "repeats": args.repeats, "folds": args.folds,
        "bootstrap_replicates": args.bootstrap, "seed": args.seed,
        "model_specification": {"type": "weighted elastic-net logistic regression",
            "C": args.c, "l1_ratio": args.l1_ratio,
            "class_weight_positive": OUTCOME_WEIGHT,
            "class_weight_negative": 1,
            "optimizer": "deterministic NumPy proximal Newton with coordinate descent",
            "optimizer_max_iter": args.max_iter, "optimizer_tol": args.tol,
            "features": {k: list(v) for k, v in MODEL_INDICES.items()}},
        "analysis_specification": {
            "point_estimate": "Each participant's mean OOF probability over repetitions",
            "ci": "Percentile bootstrap resampling participants once per replicate, shared across models",
            "cv_splits": "NumPy reproduction of scikit-learn StratifiedKFold(shuffle=True, random_state=repeat)",
            "roc_pr": "Derived from one mean OOF score per participant",
            "thresholds": "Upper 20% and 10% of raw OOF risk, descriptive only until calibration",
            "calibration": "deferred; raw probabilities and fold assignments retained",
            "s9_nonlinear": "deferred",
            "figure5_figure6": "unchanged; no diet ablation computed",
            "s13": "out of scope"},
        "completed_combinations": [],
    }
    manifest_path = output / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(checks, ensure_ascii=False), flush=True)
    if args.validate_only:
        manifest["status"] = "validated_only"
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        return
    n = len(participant_id)
    rng = np.random.default_rng(args.seed)
    bootstrap_indices = rng.integers(0, n, size=(args.bootstrap, n), dtype=np.int32)
    save(output / "bootstrap_participant_indices.npy", bootstrap_indices)
    metrics_rows = []
    threshold_rows = []
    paired_rows = []
    prediction_cache = {}
    for outcome in OUTCOME_ORDER:
        y = labels[outcome]
        for model in MODEL_ORDER:
            indices = MODEL_INDICES[model]
            xx = np.ascontiguousarray(x[:, indices])
            prefix = f"{outcome}__{model}"
            folder = output / "combinations" / prefix
            folder.mkdir(parents=True, exist_ok=True)
            oof = np.full((args.repeats, n), np.nan, dtype=np.float32)
            fold_id = np.full((args.repeats, n), -1, dtype=np.int8)
            coefficients = np.full((args.repeats, args.folds, len(indices)+1), np.nan,
                                   dtype=np.float32)
            iterations = np.zeros((args.repeats, args.folds), dtype=np.int16)
            converged = np.zeros((args.repeats, args.folds), dtype=np.int8)
            fit_initial = None
            for repeat in range(args.repeats):
                folds = stratified_folds(y, args.folds, args.seed+repeat)
                fold_id[repeat] = folds
                for fold in range(args.folds):
                    test = folds == fold
                    train = ~test
                    fit_initial, iteration, success = fit_weighted_elasticnet_lr(
                        xx[train], y[train], OUTCOME_WEIGHT[outcome], c=args.c,
                        l1_ratio=args.l1_ratio, max_iter=args.max_iter,
                        tol=args.tol, initial=fit_initial)
                    coefficients[repeat, fold] = fit_initial
                    iterations[repeat, fold] = iteration
                    converged[repeat, fold] = success
                    oof[repeat, test] = sigmoid(xx[test] @ fit_initial[1:] + fit_initial[0])
                if not np.isfinite(oof[repeat]).all():
                    raise AssertionError(f"Missing OOF scores: {prefix}, repeat {repeat}")
                if (repeat+1) % 10 == 0 or repeat == 0:
                    print(f"{prefix}: {repeat+1}/{args.repeats} repeats", flush=True)
            p = oof.astype(np.float64).mean(axis=0)
            prediction_cache[model] = p
            repeat_metrics = np.array([performance(y, scores.astype(np.float64))
                                       for scores in oof])
            boot = bootstrap_metrics(y, p, bootstrap_indices)
            point = performance(y, p)
            ci = np.nanpercentile(boot, [2.5, 97.5], axis=0)
            fpr, tpr, roc_thresholds = roc_curve(y, p)
            precision, recall, pr_thresholds = precision_recall(y, p)
            for name, array in {
                "oof_by_repeat": oof, "oof_mean": p, "fold_id": fold_id,
                "coefficients_by_repeat_fold": coefficients,
                "coefficient_mean": coefficients.mean(axis=(0, 1)),
                "coefficient_sd_across_repeats": coefficients.mean(axis=1).std(axis=0),
                "optimizer_iterations": iterations,
                "optimizer_converged": converged,
                "repeat_metrics_auroc_ap_auprc_brier": repeat_metrics,
                "bootstrap_metrics_auroc_ap_auprc_brier": boot,
                "roc_fpr": fpr, "roc_tpr": tpr, "roc_thresholds": roc_thresholds,
                "pr_precision": precision, "pr_recall": recall,
                "pr_thresholds": pr_thresholds,
            }.items():
                save(folder / f"{name}.npy", array)
            metrics_rows.append((outcome, model, n, int(y.sum()),
                *point.tolist(), *ci[0].tolist(), *ci[1].tolist(),
                float(repeat_metrics[:, 0].mean()), int(np.sum(converged == 0))))
            for fraction in (0.2, 0.1):
                threshold_rows.append((outcome, model, *top_risk_metrics(y, p, fraction)))
            manifest["completed_combinations"].append(prefix)
            manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False),
                                     encoding="utf-8")
        for m1, m2 in (("model2", "model1"), ("model3", "model1"),
                       ("combined", "model3"), ("combined", "model2")):
            d = np.full(args.bootstrap, np.nan)
            for b, ix in enumerate(bootstrap_indices):
                yy = y[ix]
                if yy.min() != yy.max():
                    d[b] = performance(yy, prediction_cache[m1][ix])[0] - \
                           performance(yy, prediction_cache[m2][ix])[0]
            point_delta = performance(y, prediction_cache[m1])[0] - \
                          performance(y, prediction_cache[m2])[0]
            lower, upper = np.nanpercentile(d, [2.5, 97.5])
            paired_rows.append((outcome, m1, m2, point_delta, lower, upper))
            save(output / "paired_auc_bootstrap" / f"{outcome}__{m1}_minus_{m2}.npy", d)
    metric_dtype = [(s, "U20") for s in ("outcome", "model")] + [
        ("n", "i4"), ("events", "i4")]
    metric_dtype += [(name, "f8") for name in (
        "auroc", "average_precision", "auprc_trapezoid", "brier_raw",
        "auroc_ci_lo", "ap_ci_lo", "auprc_ci_lo", "brier_ci_lo",
        "auroc_ci_hi", "ap_ci_hi", "auprc_ci_hi", "brier_ci_hi",
        "mean_repeat_auroc")]
    metric_dtype += [("nonconverged_fits", "i4")]
    save(output / "metrics_uncalibrated.npy", np.array(metrics_rows, dtype=metric_dtype))
    threshold_dtype = [("outcome", "U20"), ("model", "U20"),
        ("fraction", "f8"), ("selected_n", "i4"), ("cutoff_raw", "f8")]
    threshold_dtype += [(key, "i4") for key in ("tp", "fp", "fn", "tn")]
    threshold_dtype += [(key, "f8") for key in ("sensitivity", "specificity", "ppv", "npv")]
    save(output / "thresholds_uncalibrated.npy",
         np.array(threshold_rows, dtype=threshold_dtype))
    paired_dtype = [("outcome", "U20"), ("model_a", "U20"), ("model_b", "U20"),
                    ("auc_delta", "f8"), ("ci_lo", "f8"), ("ci_hi", "f8")]
    save(output / "paired_auc_deltas.npy", np.array(paired_rows, dtype=paired_dtype))
    manifest["status"] = "complete"
    manifest["elapsed_seconds"] = round(time.time()-start, 1)
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Complete: {output} ({manifest['elapsed_seconds']} s)", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=SOURCE_DIR)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--repeats", type=int, default=100)
    parser.add_argument("--folds", type=int, default=10)
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--c", type=float, default=0.1)
    parser.add_argument("--l1-ratio", type=float, default=0.3)
    parser.add_argument("--max-iter", type=int, default=80)
    parser.add_argument("--tol", type=float, default=2e-5)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    if args.repeats < 1 or args.folds < 2 or args.folds > 127 or args.bootstrap < 1:
        parser.error("Invalid repeats, folds, or bootstrap count.")
    if not (0 < args.c and 0 <= args.l1_ratio <= 1 and args.tol > 0):
        parser.error("Invalid logistic-regression parameters.")
    execute(args)


if __name__ == "__main__":
    main()
